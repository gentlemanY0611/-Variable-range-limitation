import {
  Extension,
  extension,
  settings,
} from "@avg-studio/sdk";
import type { ExtensionContext, SettingsBuilder } from "@avg-studio/sdk";

/* ============================== 数据结构 ============================== */

/** 一条变量范围规则：变量名 + 可选下限/上限（未填的一侧不限制） */
type BoundRule = {
  variable?: string;
  min?: number;
  max?: number;
};

/* ============================ 全局钳制逻辑 ============================ */

/** 串行队列：variable:changed 可能密集触发，保证钳制过程不重叠 */
let enforceQueue: Promise<void> = Promise.resolve();

function enqueue(ctx: ExtensionContext): void {
  enforceQueue = enforceQueue
    .then(() => enforceAll(ctx))
    .catch((err) => console.warn("[变量范围限定v1.1.0]", err));
}

/**
 * 读取设置里的变量范围列表，逐个钳制越界变量。
 * 写入后引擎会再触发一次 variable:changed → 重新检查时值已在边界内，
 * 与边界相等不写回，因此不会产生写回循环（天然防自我循环）。
 */
async function enforceAll(ctx: ExtensionContext): Promise<void> {
  const enabled = ctx.settings.get<boolean>("enabled") ?? true;
  if (!enabled) return;

  const raw = ctx.settings.get<Array<Record<string, unknown>>>("bounds");
  if (!Array.isArray(raw) || raw.length === 0) return;

  for (const b of raw) {
    if (!b || typeof b.variable !== "string") continue;
    const name = b.variable.trim();
    if (!name) continue;

    const min = Number.isFinite(b.min) ? (b.min as number) : undefined;
    const max = Number.isFinite(b.max) ? (b.max as number) : undefined;
    if (min === undefined && max === undefined) continue;

    // 防御：下限大于上限时自动交换，保证 max >= min
    let lo = min;
    let hi = max;
    if (lo !== undefined && hi !== undefined && lo > hi) {
      const t = lo;
      lo = hi;
      hi = t;
      console.warn(
        `[变量范围限定v1.1.0] 变量「${name}」的下限大于上限，已自动交换处理。`,
      );
    }

    const cur = ctx.variables.get<number>(name);
    if (typeof cur !== "number" || !Number.isFinite(cur)) continue;

    let next = cur;
    if (hi !== undefined && next > hi) next = hi;
    if (lo !== undefined && next < lo) next = lo;
    if (next === cur) continue;

    ctx.variables.set(name, next);
    console.log(
      `[变量范围限定v1.1.0] 变量「${name}」${cur} → ${next}` +
        `（${cur > next ? "超过上限" : "低于下限"}，已回正）`,
    );
  }
}

/* ============================== 扩展本体 ============================== */

@extension({
  id: "variable-bounds",
  label: "变量范围限定v1.1.0",
  description:
    "为任意数值变量设置上下限：任何时刻变量不会超过上限、不会低于下限；在扩展设置里用「添加变量」按钮逐条添加要约束的变量。",
})
export class VariableBounds extends Extension {
  /**
   * 项目级设置：总开关 + 变量范围列表（array 字段自带「+ 添加变量」按钮，
   * 随项目配置持久化，无需数据集合）。
   */
  static settings = settings((s: SettingsBuilder) => ({
    enabled: s
      .boolean("变量范围限定")
      .default(true)
      .describe("总开关：关闭后不再自动钳制变量范围。"),
    bounds: s
      .array("变量范围列表", (item) => {
        const it = item as {
          string(label: string): {
            describe(text: string): unknown;
          };
          number(label: string): {
            default(value: number): { describe(text: string): unknown };
          };
        };
        return {
          variable: it
            .string("变量名")
            .describe("填写项目中已声明的数值变量名（如 天数、好感度）。"),
          min: it
            .number("下限")
            .default(0)
            .describe("变量不允许低于该值；不填则不限下限。"),
          max: it
            .number("上限")
            .default(100)
            .describe("变量不允许高于该值；不填则不限上限。"),
        };
      })
      .addLabel("+ 添加变量")
      .describe(
        "点击「+ 添加变量」添加一个变量及其上下限，可添加多个；变量任何时刻都不会超过上限或低于下限。",
      ),
  }));

  /** 模块级全局钩子：监听所有运行时变量变化，实时钳制范围 */
  static onRegister(ctx: ExtensionContext): void {
    ctx.subscribe("variable:changed", () => {
      enqueue(ctx);
    });
    console.log("[变量范围限定v1.1.0] 全局变量范围钳制已挂载。");
  }
}
